# 11. Upload e Biblioteca Digital

## Upload implementado

O UploadThing possui duas rotas lógicas:

- `avatar`: uma imagem de até 4 MB;
- `affiliateDocument`: PDF ou imagem, até três arquivos de 8 MB.

Ambas exigem sessão autenticada.

## Limitações do upload atual

O callback retorna URL e usuário, mas não foi localizada persistência completa no banco para os documentos enviados.

## Biblioteca digital solicitada

Não existe implementação de:

- modelo `DigitalAsset`;
- painel administrativo de upload;
- barra de progresso de publicação;
- classificação de arquivo;
- visibilidade pública ou privada;
- geração de link público;
- compartilhamento WhatsApp;
- expiração de link;
- exclusão;
- auditoria;
- download no dashboard.

## Modelo recomendado

Um modelo futuro deve conter pelo menos:

- ID;
- título;
- descrição;
- URL;
- chave do provedor;
- MIME type;
- tamanho;
- visibilidade;
- status;
- criado por;
- datas de criação, atualização e expiração.
