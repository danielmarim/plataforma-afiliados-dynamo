# 1. Visão Geral

A Plataforma de Afiliados Dynamo é uma aplicação web para cadastro, autenticação e futura gestão de afiliados integrados à Shopify.

O código atual fornece uma fundação para:

- cadastro e autenticação de afiliados;
- perfil de afiliado e papéis `ADMIN` e `AFFILIATE`;
- modelagem de cupons, vendas, comissões, pagamentos e conversões;
- upload de avatar e documentos;
- comunicação por e-mail;
- conexão genérica com a Shopify Admin GraphQL API;
- auditoria de solicitações de conversão;
- notificações por e-mail, WhatsApp e dentro da aplicação.

## Estado atual por módulo

| Módulo | Situação | Observação |
|---|---|---|
| Estrutura Next.js e layouts | Implementado | App Router, layouts público/protegido e página inicial. |
| Cadastro de usuário/afiliado | Implementado | Server Action, validação Zod, bcrypt e criação transacional. |
| Login por credenciais | Implementado | Auth.js v5 com sessão JWT. |
| Proteção de rotas | Implementado com ressalvas | Middleware protege páginas, mas libera todas as rotas /api. |
| Dashboard do afiliado | Parcial | Página e navegação básicas; métricas reais e módulos finais ainda faltam. |
| Recuperação de senha | Parcial | Tela e formulário existem; token, e-mail e redefinição ainda não estão completos. |
| Upload de avatar/documentos | Base implementada | UploadThing configurado, sem persistência completa dos metadados no domínio. |
| Biblioteca digital | Não implementado | Sem modelo DigitalAsset, gestão administrativa ou links públicos. |
| Shopify Admin GraphQL | Base implementada | Cliente genérico pronto; operações específicas não implementadas. |
| Webhooks Shopify | Não implementado | Sem rotas, HMAC, idempotência e processamento de pedidos. |
| Cálculo de comissões | Modelado/parcial | Modelos e conversão existem; ingestão das vendas e fechamento ainda faltam. |
| Conversão de saldo em cupom | Parcial | Regras principais implementadas, mas criação Shopify é mock. |
| Painel administrativo | Não implementado | Sem telas e rotas administrativas dedicadas. |
| E-mail | Base implementada | Cliente Resend pronto; templates e processamento de notificações faltam. |
| WhatsApp | Somente modelado | Canal existe no banco, sem provedor/conector. |
| Testes automatizados | Não implementado | Sem testes unitários, integração ou E2E. |
| CI/CD | Não implementado | Sem workflows no GitHub Actions. |
| Migrações Prisma | Não incluído | Existe schema, mas não há prisma/migrations. |

## Escopo identificado no banco

Os modelos Prisma representam os seguintes domínios:

- identidade e autenticação;
- perfil e aprovação de afiliados;
- cupons;
- vendas originadas na Shopify;
- comissões;
- pagamentos;
- conversão de saldo em cupom;
- notificações;
- configurações;
- webhooks;
- auditoria.

## Limitação desta versão

O projeto ainda não contém a experiência administrativa completa nem o processamento real dos eventos da Shopify. A documentação descreve esses pontos como lacunas, em vez de assumir que estão funcionando.
