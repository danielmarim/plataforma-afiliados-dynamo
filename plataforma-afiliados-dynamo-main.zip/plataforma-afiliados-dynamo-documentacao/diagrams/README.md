# Diagramas

Os diagramas usam Mermaid e podem ser renderizados diretamente pelo GitHub.

## Arquitetura

```mermaid
flowchart TB
    User[Afiliado/Admin] --> UI[Next.js UI]
    UI --> Auth[Auth.js]
    UI --> Actions[Server Actions]
    UI --> API[API Routes]
    Actions --> Domain[Serviços]
    API --> Domain
    Domain --> Prisma[Prisma]
    Prisma --> DB[(PostgreSQL)]
    Domain --> Shopify[Shopify]
    Domain --> Resend[Resend]
    API --> UploadThing[UploadThing]
```

## Domínio principal

```mermaid
flowchart LR
    Affiliate --> Coupon
    Coupon --> Sale
    Sale --> Commission
    Commission --> Payout
    Commission --> ConversionRequest
    ConversionRequest --> GeneratedCoupon
```

## Aprovação de conversão

```mermaid
sequenceDiagram
    participant A as Afiliado
    participant App as Plataforma
    participant Admin as Administrador
    participant Shop as Shopify
    A->>App: Solicita conversão
    App->>App: Valida saldo e reserva
    Admin->>App: Aprova
    App->>Shop: Cria desconto
    Shop-->>App: Retorna ID
    App->>App: Salva código e validade
    App-->>A: Envia notificações
```

A etapa Shopify acima representa o fluxo-alvo. No código atual, a criação do desconto ainda é mock.
