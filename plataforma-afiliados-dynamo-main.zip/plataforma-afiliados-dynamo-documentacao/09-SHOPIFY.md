# 9. Integração Shopify

## Implementado

O arquivo `services/shopify.service.ts` fornece uma função genérica para chamar a Shopify Admin GraphQL API.

Configurações usadas:

- domínio da loja;
- token de acesso administrativo;
- versão da API;
- endpoint GraphQL.

## Não implementado

- criação real de cupom de valor fixo;
- configuração de uso único;
- validade de 15 dias na Shopify;
- consulta e sincronização de pedidos;
- registro de webhooks;
- validação HMAC;
- tratamento de pedidos pagos, cancelados e reembolsados;
- atribuição por código de cupom;
- idempotência;
- atualização de status da comissão.

## Fluxo futuro recomendado

```mermaid
sequenceDiagram
    participant S as Shopify
    participant W as Webhook API
    participant D as Banco
    participant C as Comissão
    S->>W: orders/paid
    W->>W: Valida HMAC
    W->>D: Verifica webhookId
    W->>D: Localiza cupom/afiliado
    W->>D: Salva venda
    W->>C: Calcula comissão
    C->>D: Salva comissão
    W-->>S: HTTP 200
```

## Escopos

O token da Shopify deverá possuir os escopos mínimos necessários para pedidos, descontos e webhooks. Os escopos exatos devem ser definidos conforme as operações GraphQL finais.
