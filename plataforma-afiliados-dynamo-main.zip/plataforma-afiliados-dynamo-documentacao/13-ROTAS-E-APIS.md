# 13. Rotas e APIs

## Rotas encontradas

| Rota | Arquivo | Tipo |
|---|---|---|
| /forgot-password | app/(auth)/forgot-password/page.tsx | Página |
| /login | app/(auth)/login/page.tsx | Página |
| /register | app/(auth)/register/page.tsx | Página |
| /dashboard | app/(dashboard)/dashboard/page.tsx | Página |
| /api/auth/[...nextauth] | app/api/auth/[...nextauth]/route.ts | API Route |
| /api/uploadthing | app/api/uploadthing/route.ts | API Route |
| / | app/page.tsx | Página |

## APIs existentes

### `/api/auth/[...nextauth]`

Handler do Auth.js.

### `/api/uploadthing`

Handler do UploadThing.

## APIs ausentes

Não foram encontradas APIs para:

- webhooks Shopify;
- solicitações de conversão;
- aprovação/reprovação;
- afiliados;
- vendas;
- comissões;
- notificações;
- biblioteca;
- relatórios;
- configurações.

## Convenção recomendada

```text
/api/admin/affiliates
/api/admin/conversions
/api/affiliate/conversions
/api/webhooks/shopify
/api/assets
/api/notifications
```

Cada rota deve validar:

- autenticação;
- papel;
- propriedade do recurso;
- payload;
- idempotência quando aplicável;
- logs.
