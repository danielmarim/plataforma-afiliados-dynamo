# 3. Tecnologias e Dependências

## Stack confirmada pelo `package.json`

| Pacote | Versão | Finalidade |
|---|---|---|
| @auth/prisma-adapter | ^2.11.3 | Persistência do Auth.js via Prisma |
| @hookform/resolvers | ^5.4.0 | Integração Zod e React Hook Form |
| @prisma/client | ^6.19.3 | ORM e acesso ao PostgreSQL |
| @radix-ui/react-label | ^2.1.12 | Dependência de suporte do projeto |
| @radix-ui/react-slot | ^1.3.0 | Dependência de suporte do projeto |
| @supabase/supabase-js | ^2.110.8 | Cliente Supabase |
| @tanstack/react-table | ^8.21.3 | Tabelas avançadas |
| @uploadthing/react | ^7.3.3 | Upload de arquivos no cliente |
| bcryptjs | ^3.0.3 | Hash e validação de senhas |
| class-variance-authority | ^0.7.1 | Dependência de suporte do projeto |
| clsx | ^2.1.1 | Dependência de suporte do projeto |
| lucide-react | ^1.25.0 | Ícones |
| next | 15.5.21 | Framework full-stack e App Router |
| next-auth | 5.0.0-beta.32 | Autenticação Auth.js v5 |
| next-themes | ^0.4.6 | Dependência de suporte do projeto |
| radix-ui | ^1.6.4 | Primitivos acessíveis de interface |
| react | 19.1.0 | Biblioteca de interface |
| react-dom | 19.1.0 | Renderização React no navegador |
| react-hook-form | ^7.82.0 | Gerenciamento de formulários |
| recharts | ^3.10.0 | Gráficos |
| resend | ^6.18.0 | Envio de e-mails |
| shadcn | ^4.14.0 | Componentes e tooling Shadcn |
| sonner | ^2.0.7 | Notificações toast |
| tailwind-merge | ^3.6.0 | Dependência de suporte do projeto |
| tw-animate-css | ^1.4.0 | Dependência de suporte do projeto |
| uploadthing | ^7.7.4 | Upload de arquivos no servidor |
| zod | ^4.4.3 | Validação de dados |
| @eslint/eslintrc | ^3 | Dependência de suporte do projeto |
| @tailwindcss/postcss | ^4 | Dependência de suporte do projeto |
| @types/node | ^20 | Dependência de suporte do projeto |
| @types/react | ^19 | Dependência de suporte do projeto |
| @types/react-dom | ^19 | Dependência de suporte do projeto |
| eslint | ^9 | Dependência de suporte do projeto |
| eslint-config-next | 15.5.21 | Dependência de suporte do projeto |
| prisma | ^6.19.3 | CLI, geração do client e schema |
| tailwindcss | ^4 | Estilização utilitária |
| typescript | ^5 | Tipagem estática |

## Gerenciador de pacotes

O projeto utiliza **pnpm**, confirmado por:

- `pnpm-lock.yaml`
- `pnpm-workspace.yaml`

## Banco de dados

O ORM é Prisma e o datasource utiliza PostgreSQL. O README indica Supabase como provedor do banco.

## Interface

A camada visual combina:

- Tailwind CSS 4;
- Shadcn;
- componentes Radix UI;
- Lucide React;
- Sonner;
- Recharts;
- TanStack Table.

## Compatibilidade

Antes de atualizar dependências, deve-se validar especialmente:

- Next.js 15;
- React 19;
- Auth.js 5 beta;
- Prisma 6;
- Zod 4;
- Tailwind 4.

Essas versões podem ter mudanças incompatíveis com exemplos mais antigos encontrados na internet.
