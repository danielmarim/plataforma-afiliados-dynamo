# 14. Variáveis de Ambiente

## Variáveis identificadas ou implicitamente necessárias

| Variável | Finalidade | Segurança |
|---|---|---|
| AUTH_SECRET | Assinatura e segurança do Auth.js | Não versionar valor real |
| AUTH_URL | URL base do Auth.js | Não versionar valor real |
| EMAIL_FROM | Remetente de e-mail | Não versionar valor real |
| NEXT_PUBLIC_SUPABASE_ANON_KEY | Chave anônima pública do Supabase | Não versionar valor real |
| NEXT_PUBLIC_SUPABASE_URL | URL pública do Supabase | Não versionar valor real |
| NODE_ENV | Configuração encontrada no código | Não versionar valor real |
| RESEND_API_KEY | Autenticação no Resend | Não versionar valor real |
| SHOPIFY_ADMIN_API_ACCESS_TOKEN | Token Admin API | Não versionar valor real |
| SHOPIFY_API_VERSION | Versão da Admin API | Não versionar valor real |
| SHOPIFY_STORE_DOMAIN | Domínio myshopify da loja | Não versionar valor real |
| SUPABASE_SERVICE_ROLE_KEY | Chave privilegiada do Supabase; somente servidor | Não versionar valor real |

## `.env.example` recomendado

```env
DATABASE_URL=
DIRECT_URL=

AUTH_SECRET=
AUTH_URL=http://localhost:3000

NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

RESEND_API_KEY=
EMAIL_FROM=Dynamo <no-reply@seudominio.com>

SHOPIFY_STORE_DOMAIN=
SHOPIFY_ADMIN_API_ACCESS_TOKEN=
SHOPIFY_API_VERSION=2025-07

UPLOADTHING_TOKEN=
```

O arquivo `.env.example` não estava presente no pacote analisado.

Nunca versionar tokens, senhas, chaves privadas ou dados reais de produção.
