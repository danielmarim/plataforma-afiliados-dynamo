# 20. Roadmap Recomendado

## Fase 1 — Corrigir fundação

- corrigir relação do revisor;
- criar migrations;
- adicionar `.env.example`;
- adicionar CI;
- criar testes da conversão;
- proteger APIs por papel.

## Fase 2 — Shopify

- implementar cliente de descontos;
- criar cupom de valor fixo;
- limitar a um uso;
- definir expiração;
- registrar webhooks;
- validar HMAC;
- implementar idempotência.

## Fase 3 — Comissões

- processar pedidos pagos;
- atribuir cupom;
- criar venda;
- calcular comissão;
- tratar cancelamento e reembolso;
- vincular comissão à conversão.

## Fase 4 — Administração

- fila de aprovação;
- botões Aprovar e Reprovar;
- gestão de afiliados;
- visão de vendas e comissões;
- auditoria;
- relatórios.

## Fase 5 — Comunicação e biblioteca

- worker de notificações;
- templates Resend;
- provedor WhatsApp;
- biblioteca digital;
- links públicos;
- barra de progresso;
- compartilhamento.

## Fase 6 — Produção

- observabilidade;
- rate limiting;
- política LGPD;
- backup;
- testes E2E;
- runbooks;
- SLOs.
