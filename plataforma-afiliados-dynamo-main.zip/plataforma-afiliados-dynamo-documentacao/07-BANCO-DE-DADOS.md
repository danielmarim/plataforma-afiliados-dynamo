# 7. Banco de Dados

## Tecnologia

- ORM: Prisma
- Banco: PostgreSQL
- Provedor indicado: Supabase
- Schema: `prisma/schema.prisma`

## Enums

## `UserRole`

- `ADMIN`
- `AFFILIATE`
## `AffiliateStatus`

- `PENDING`
- `ACTIVE`
- `SUSPENDED`
- `INACTIVE`
## `CouponStatus`

- `ACTIVE`
- `INACTIVE`
- `EXPIRED`
## `SaleStatus`

- `PENDING`
- `APPROVED`
- `CANCELLED`
- `REFUNDED`
## `CommissionStatus`

- `PENDING`
- `APPROVED`
- `PAID`
- `CANCELLED`
## `PayoutStatus`

- `REQUESTED`
- `PROCESSING`
- `PAID`
- `REJECTED`
## `PayoutMethod`

- `PIX`
- `BANK_TRANSFER`
## `NotificationChannel`

- `EMAIL`
- `WHATSAPP`
- `IN_APP`
## `NotificationStatus`

- `PENDING`
- `SENT`
- `FAILED`
- `READ`
## `ConversionStatus`

- `PENDING`
- `APPROVED`
- `REJECTED`
- `CANCELLED`

## Modelos

## `User`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| name | String? | — |
| email | String | @unique |
| emailVerified | DateTime? | — |
| passwordHash | String? | — |
| image | String? | — |
| role | UserRole | @default(AFFILIATE) |
| createdAt | DateTime | @default(now()) |
| updatedAt | DateTime | @updatedAt |
| accounts | Account[] | — |
| sessions | Session[] | — |
| affiliate | Affiliate? | — |
## `Account`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| userId | String | — |
| type | String | — |
| provider | String | — |
| providerAccountId | String | — |
| refresh_token | String? | @db.Text |
| access_token | String? | @db.Text |
| expires_at | Int? | — |
| token_type | String? | — |
| scope | String? | — |
| id_token | String? | @db.Text |
| session_state | String? | — |
| user | User | @relation(fields: [userId], references: [id], onDelete: Cascade) |
## `Session`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| sessionToken | String | @unique |
| userId | String | — |
| expires | DateTime | — |
| user | User | @relation(fields: [userId], references: [id], onDelete: Cascade) |
## `VerificationToken`

| Campo | Tipo | Atributos |
|---|---|---|
| identifier | String | — |
| token | String | @unique |
| expires | DateTime | — |
## `PasswordResetToken`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| email | String | — |
| token | String | @unique |
| expires | DateTime | — |
## `Affiliate`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| userId | String | @unique |
| status | AffiliateStatus | @default(PENDING) |
| phone | String? | — |
| whatsapp | String? | — |
| instagram | String? | — |
| tiktok | String? | — |
| document | String? | // CPF/CNPJ |
| pixKey | String? | — |
| bankInfo | Json? | — |
| commissionRate | Decimal | @default(10.00) @db.Decimal(5, 2) |
| notes | String? | @db.Text |
| approvedAt | DateTime? | — |
| createdAt | DateTime | @default(now()) |
| updatedAt | DateTime | @updatedAt |
| user | User | @relation(fields: [userId], references: [id], onDelete: Cascade) |
| coupons | Coupon[] | — |
| sales | Sale[] | — |
| commissions | Commission[] | — |
| payouts | Payout[] | — |
| notifications | Notification[] | — |
| conversionRequests | ConversionRequest[] | — |
| conversionReviews | ConversionRequest[] | @relation("ReviewedBy") |
| auditLogs | AuditLog[] | — |
## `ConversionRequest`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| affiliateId | String | — |
| requestedAmount | Decimal | @db.Decimal(12, 2) |
| status | ConversionStatus | @default(PENDING) |
| rejectionReason | String? | @db.Text |
| generatedCouponCode | String? | @unique |
| shopifyDiscountId | String? | @unique |
| expiresAt | DateTime? | — |
| approvedAt | DateTime? | — |
| rejectedAt | DateTime? | — |
| reviewedById | String? | — |
| createdAt | DateTime | @default(now()) |
| updatedAt | DateTime | @updatedAt |
| affiliate | Affiliate | @relation(fields: [affiliateId], references: [id], onDelete: Cascade) |
| reviewedBy | Affiliate? | @relation("ReviewedBy", fields: [reviewedById], references: [id], onDelete: SetNull) |
| auditLogs | AuditLog[] | — |
| notifications | Notification[] | — |
## `AuditLog`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| affiliateId | String | — |
| conversionRequestId | String? | — |
| action | String | // CREATE, APPROVE, REJECT, etc. |
| description | String | @db.Text |
| metadata | Json? | — |
| createdAt | DateTime | @default(now()) |
| affiliate | Affiliate | @relation(fields: [affiliateId], references: [id], onDelete: Cascade) |
| conversionRequest | ConversionRequest? | @relation(fields: [conversionRequestId], references: [id], onDelete: SetNull) |
## `Coupon`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| affiliateId | String | — |
| code | String | @unique |
| status | CouponStatus | @default(ACTIVE) |
| discountType | String | @default("percentage") // percentage | fixed_amount |
| discountValue | Decimal | @db.Decimal(10, 2) |
| shopifyPriceRuleId | String? | @unique |
| shopifyDiscountId | String? | @unique |
| usageCount | Int | @default(0) |
| usageLimit | Int? | — |
| startsAt | DateTime? | — |
| expiresAt | DateTime? | — |
| createdAt | DateTime | @default(now()) |
| updatedAt | DateTime | @updatedAt |
| affiliate | Affiliate | @relation(fields: [affiliateId], references: [id], onDelete: Cascade) |
| sales | Sale[] | — |
## `Sale`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| affiliateId | String | — |
| couponId | String? | — |
| status | SaleStatus | @default(PENDING) |
| shopifyOrderId | String | @unique |
| shopifyOrderNumber | String? | — |
| customerEmail | String? | — |
| totalAmount | Decimal | @db.Decimal(12, 2) |
| discountAmount | Decimal | @default(0) @db.Decimal(12, 2) |
| currency | String | @default("BRL") |
| orderDate | DateTime | — |
| createdAt | DateTime | @default(now()) |
| updatedAt | DateTime | @updatedAt |
| affiliate | Affiliate | @relation(fields: [affiliateId], references: [id]) |
| coupon | Coupon? | @relation(fields: [couponId], references: [id]) |
| commission | Commission? | — |
## `Commission`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| affiliateId | String | — |
| saleId | String | @unique |
| status | CommissionStatus | @default(PENDING) |
| rate | Decimal | @db.Decimal(5, 2) |
| amount | Decimal | @db.Decimal(12, 2) |
| currency | String | @default("BRL") |
| payoutId | String? | — |
| approvedAt | DateTime? | — |
| paidAt | DateTime? | — |
| createdAt | DateTime | @default(now()) |
| updatedAt | DateTime | @updatedAt |
| affiliate | Affiliate | @relation(fields: [affiliateId], references: [id]) |
| sale | Sale | @relation(fields: [saleId], references: [id]) |
| payout | Payout? | @relation(fields: [payoutId], references: [id]) |
## `Payout`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| affiliateId | String | — |
| status | PayoutStatus | @default(REQUESTED) |
| method | PayoutMethod | @default(PIX) |
| amount | Decimal | @db.Decimal(12, 2) |
| currency | String | @default("BRL") |
| reference | String? | — |
| notes | String? | @db.Text |
| requestedAt | DateTime | @default(now()) |
| processedAt | DateTime? | — |
| createdAt | DateTime | @default(now()) |
| updatedAt | DateTime | @updatedAt |
| affiliate | Affiliate | @relation(fields: [affiliateId], references: [id]) |
| commissions | Commission[] | — |
## `Notification`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| affiliateId | String? | — |
| conversionRequestId | String? | — |
| channel | NotificationChannel | — |
| status | NotificationStatus | @default(PENDING) |
| title | String | — |
| body | String | @db.Text |
| metadata | Json? | — |
| sentAt | DateTime? | — |
| readAt | DateTime? | — |
| createdAt | DateTime | @default(now()) |
| affiliate | Affiliate? | @relation(fields: [affiliateId], references: [id], onDelete: SetNull) |
| conversionRequest | ConversionRequest? | @relation(fields: [conversionRequestId], references: [id], onDelete: SetNull) |
## `Setting`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| key | String | @unique |
| value | Json | — |
| updatedAt | DateTime | @updatedAt |
## `WebhookEvent`

| Campo | Tipo | Atributos |
|---|---|---|
| id | String | @id @default(cuid()) |
| source | String | @default("shopify") |
| topic | String | — |
| payload | Json | — |
| processed | Boolean | @default(false) |
| processedAt | DateTime? | — |
| error | String? | @db.Text |
| createdAt | DateTime | @default(now()) |

## Relações de negócio principais

```mermaid
erDiagram
    User ||--o| Affiliate : possui
    Affiliate ||--o{ Coupon : possui
    Affiliate ||--o{ Sale : recebe_atribuicao
    Sale ||--o| Commission : gera
    Affiliate ||--o{ Commission : recebe
    Affiliate ||--o{ Payout : solicita
    Payout ||--o{ Commission : agrupa
    Affiliate ||--o{ ConversionRequest : solicita
    ConversionRequest ||--o{ Notification : gera
    ConversionRequest ||--o{ AuditLog : registra
```

## Valores monetários

Os campos financeiros usam `Decimal`, adequado para evitar erros de ponto flutuante.

## Migrações

O pacote não contém `prisma/migrations/`. Portanto, o histórico do banco não está versionado.

## Inconsistência crítica

`ConversionRequest.reviewedById` está relacionado a `Affiliate`, enquanto o serviço valida e utiliza um `User` administrador. Isso precisa ser corrigido no schema ou na lógica antes de executar aprovações em produção.

## Lacuna de rastreabilidade

Não existe uma tabela que vincule uma solicitação de conversão às comissões consumidas. Recomenda-se criar uma relação explícita para evitar dupla utilização e permitir auditoria financeira.
