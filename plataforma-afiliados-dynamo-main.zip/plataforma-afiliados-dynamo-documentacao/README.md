# Documentação Técnica — Plataforma de Afiliados Dynamo

Documentação gerada a partir do código-fonte presente no arquivo analisado.

**Versão do projeto:** `0.1.0`  
**Arquivos analisados:** `69`  
**Framework principal:** Next.js `15.5.21`  
**Status geral:** base funcional em desenvolvimento, com autenticação e domínio modelados, mas integrações e módulos administrativos ainda parciais.

## Princípio desta documentação

A documentação distingue claramente:

- **Implementado:** existe código funcional no pacote.
- **Parcial:** existe estrutura ou parte da lógica.
- **Modelado:** está representado no banco ou tipos, mas sem fluxo executável completo.
- **Não implementado:** não foi localizado código correspondente.
- **Mock:** fluxo simulado, sem integração real com o serviço externo.

## Índice

1. [Visão geral](01-VISAO-GERAL.md)
2. [Arquitetura](02-ARQUITETURA.md)
3. [Tecnologias e dependências](03-TECNOLOGIAS.md)
4. [Estrutura do código](04-ESTRUTURA-DO-CODIGO.md)
5. [Frontend](05-FRONTEND.md)
6. [Backend e Server Actions](06-BACKEND.md)
7. [Banco de dados](07-BANCO-DE-DADOS.md)
8. [Autenticação e autorização](08-AUTENTICACAO.md)
9. [Integração Shopify](09-SHOPIFY.md)
10. [Conversão de saldo](10-CONVERSAO-DE-SALDO.md)
11. [Upload e biblioteca digital](11-UPLOAD-E-BIBLIOTECA.md)
12. [E-mail, WhatsApp e notificações](12-NOTIFICACOES.md)
13. [Rotas e APIs](13-ROTAS-E-APIS.md)
14. [Variáveis de ambiente](14-VARIAVEIS-DE-AMBIENTE.md)
15. [Instalação e execução](15-INSTALACAO-E-EXECUCAO.md)
16. [Deploy e operação](16-DEPLOY-E-OPERACAO.md)
17. [Segurança](17-SEGURANCA.md)
18. [Testes e qualidade](18-TESTES-E-QUALIDADE.md)
19. [Auditoria e dívida técnica](19-AUDITORIA-TECNICA.md)
20. [Roadmap recomendado](20-ROADMAP.md)
21. [Diagramas](diagrams/README.md)
22. [Inventário integral de arquivos](INVENTARIO-DE-ARQUIVOS.md)
