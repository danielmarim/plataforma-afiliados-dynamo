# 10. Conversão de Saldo em Cupom

## Objetivo

Permitir que um afiliado converta saldo de comissão em um cupom aleatório, separado do cupom permanente do afiliado.

## Regras implementadas

- afiliado deve existir;
- afiliado deve estar ativo;
- saldo é calculado com comissões aprovadas e sem pagamento;
- apenas uma solicitação pendente ou aprovada por afiliado;
- operação executada em transação serializável;
- código aleatório e único;
- validade de 15 dias;
- aprovação somente por administrador;
- rejeição devolve o valor ao saldo lógico;
- auditoria;
- registros de notificações.

## Fluxo

```mermaid
stateDiagram-v2
    [*] --> PENDING: Afiliado solicita
    PENDING --> APPROVED: Admin aprova
    PENDING --> REJECTED: Admin reprova
    APPROVED --> USED: Cupom utilizado
    APPROVED --> EXPIRED: Validade encerrada
```

## Limitações atuais

- o cupom Shopify é um mock;
- não há garantia de uso único na Shopify;
- não há job de expiração;
- não há sincronização do uso do cupom;
- não há consumo explícito das comissões;
- status aprovado é tratado como saldo reservado indefinidamente;
- a relação do revisor está inconsistente entre `User` e `Affiliate`.

## Recomendações

1. Criar o desconto real na Shopify antes de confirmar aprovação.
2. Persistir o ID GraphQL retornado.
3. Vincular comissões específicas à conversão.
4. Tratar rollback ou compensação se a Shopify falhar.
5. Criar webhook ou rotina para marcar cupom como usado.
6. Criar job para expirar solicitações.
