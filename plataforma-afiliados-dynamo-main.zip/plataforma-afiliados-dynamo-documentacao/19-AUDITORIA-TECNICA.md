# 19. Auditoria Técnica e Dívida

| Severidade | Tema | Constatação |
|---|---|---|
| Crítico | Revisor da conversão | `reviewedById` relaciona Affiliate, serviço utiliza User. |
| Crítico | Cupom Shopify mock | Aprovação pode parecer concluída sem criar desconto real. |
| Alto | Sem vínculo conversão-comissão | Risco de rastreabilidade e dupla utilização. |
| Alto | APIs liberadas | Middleware não protege automaticamente `/api`. |
| Alto | Sem webhooks/HMAC | Vendas e comissões não são sincronizadas com segurança. |
| Alto | Sem migrations | Banco não possui histórico reproduzível. |
| Médio | Recuperação de senha incompleta | Fluxo não redefine senha. |
| Médio | Notificação sem worker | Registros são criados, mensagens não são entregues. |
| Médio | Upload sem persistência de domínio | Arquivos podem não ser gerenciáveis. |
| Médio | Sem testes | Maior risco de regressões financeiras. |
| Baixo | README cita pasta ausente | `components/shared/` não existe. |

## Código e documentação

Comentários no serviço de conversão mencionam lock `SELECT FOR UPDATE`, mas o código usa `findMany`. A documentação e a implementação devem ser alinhadas.

## Integridade financeira

O saldo é calculado somando comissões aprovadas não pagas. A reserva é representada por solicitações pendentes/aprovadas, mas as comissões individuais não são marcadas como comprometidas.

## Confiabilidade externa

A criação do cupom deve ser projetada para falhas parciais. Uma transação de banco não pode incluir atomicamente a Shopify. Recomenda-se padrão de estado intermediário, retry e compensação.

## Manutenibilidade

A estrutura é pequena e clara, mas deverá crescer. Recomenda-se separar:

- domínio;
- repositórios;
- casos de uso;
- integrações;
- jobs;
- políticas de autorização.
