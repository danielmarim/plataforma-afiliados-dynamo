# 4. Estrutura do Código

## Árvore de arquivos

```text
└── .gitignore
└── README.md
    └── auth.ts
            └── page.tsx
        └── layout.tsx
            └── page.tsx
            └── page.tsx
            └── page.tsx
        └── layout.tsx
                └── route.ts
            └── route.ts
    └── favicon.ico
    └── globals.css
    └── layout.tsx
    └── page.tsx
└── components.json
        └── forgot-password-form.tsx
        └── login-form.tsx
        └── register-form.tsx
        └── sidebar-nav.tsx
        └── user-nav.tsx
        └── session-provider.tsx
        └── avatar.tsx
        └── badge.tsx
        └── button.tsx
        └── card.tsx
        └── dropdown-menu.tsx
        └── form.tsx
        └── input.tsx
        └── label.tsx
        └── separator.tsx
        └── sheet.tsx
        └── skeleton.tsx
        └── sonner.tsx
        └── table.tsx
        └── tabs.tsx
└── eslint.config.mjs
    └── use-current-user.ts
    └── use-uploadthing.ts
    └── auth.config.ts
    └── auth.ts
    └── prisma.ts
    └── resend.ts
    └── supabase.ts
    └── uploadthing.ts
    └── utils.ts
        └── auth.ts
        └── conversion.ts
└── middleware.ts
└── next.config.ts
└── package.json
└── pnpm-lock.yaml
└── pnpm-workspace.yaml
└── postcss.config.mjs
    └── schema.prisma
    └── file.svg
    └── globe.svg
    └── next.svg
    └── vercel.svg
    └── window.svg
    └── conversion.ts
    └── email.service.ts
    └── shopify.service.ts
    └── user.service.ts
└── tsconfig.json
    └── index.ts
    └── next-auth.d.ts
    └── constants.ts
    └── format.ts
```

## Responsabilidade das pastas

| Diretório | Responsabilidade |
|---|---|
| `actions/` | Server Actions, principalmente autenticação |
| `app/` | Rotas, páginas, layouts e handlers do App Router |
| `components/auth/` | Formulários de login, cadastro e recuperação |
| `components/dashboard/` | Navegação e elementos do dashboard |
| `components/providers/` | Providers React |
| `components/ui/` | Componentes reutilizáveis de interface |
| `hooks/` | Hooks de sessão e upload |
| `lib/` | Clientes, configurações, utilidades e validações |
| `prisma/` | Modelo de dados |
| `services/` | Serviços de negócio e integrações |
| `types/` | Tipos globais e extensão de sessão |
| `utils/` | Constantes e formatação |
| `public/` | Recursos estáticos |

## Observações

O README menciona `components/shared/`, mas essa pasta não está presente no pacote analisado.

Não existem no pacote:

- `tests/`;
- `.github/workflows/`;
- `prisma/migrations/`;
- `.env.example`;
- rotas administrativas;
- rotas de webhook da Shopify.
