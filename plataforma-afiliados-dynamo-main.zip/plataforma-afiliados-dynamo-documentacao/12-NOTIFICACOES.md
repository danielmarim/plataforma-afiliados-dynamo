# 12. E-mail, WhatsApp e Notificações

## E-mail

O Resend está configurado por `lib/resend.ts` e encapsulado por `services/email.service.ts`.

O serviço atual envia HTML genérico, mas ainda não contém:

- templates;
- fila;
- retry;
- registro de erro;
- rastreamento de entrega;
- gatilhos completos.

## Notificações no banco

O domínio prevê canais:

- `EMAIL`;
- `WHATSAPP`;
- `IN_APP`.

A aprovação e rejeição de conversão criam registros de notificação.

## Lacuna operacional

Criar o registro não envia efetivamente a mensagem. Não existe worker ou rotina que busque notificações pendentes e as entregue.

## WhatsApp

Não existe provedor configurado. É necessário escolher e implementar um conector, por exemplo:

- WhatsApp Cloud API;
- Evolution API;
- WPPConnect;
- Twilio;
- outro provedor compatível.

## Arquitetura recomendada

```mermaid
flowchart LR
    Domain[Evento de domínio] --> N[(Notification)]
    Worker[Worker agendado] --> N
    Worker --> Email[Resend]
    Worker --> WA[Provedor WhatsApp]
    Worker --> InApp[Central in-app]
    Worker --> Logs[(Status e tentativas)]
```
