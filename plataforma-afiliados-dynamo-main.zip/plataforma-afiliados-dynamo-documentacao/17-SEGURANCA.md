# 17. Segurança

## Pontos positivos

- hash bcrypt;
- validação Zod;
- operações sensíveis no servidor;
- uso de `server-only`;
- valores financeiros com Decimal;
- transação serializável;
- upload exige sessão;
- segredos não foram localizados no pacote.

## Riscos e pendências

### APIs liberadas pelo middleware

Todas as rotas `/api` passam pelo middleware. A autorização deve ser obrigatória em cada handler.

### Shopify

Falta validação HMAC de webhook e controle de idempotência.

### Upload

É necessário validar:

- conteúdo real do arquivo;
- extensão;
- MIME type;
- tamanho;
- acesso ao arquivo;
- remoção;
- malware quando aplicável.

### Dados pessoais e financeiros

O domínio inclui CPF/CNPJ, PIX, telefone e dados bancários. Deve haver:

- controle de acesso;
- minimização;
- criptografia ou tokenização quando aplicável;
- logs sem dados sensíveis;
- política LGPD;
- retenção e exclusão.

### Rate limiting

Aplicar pelo menos em:

- login;
- cadastro;
- recuperação de senha;
- webhooks;
- upload;
- solicitações de conversão.

### Auditoria

A auditoria de conversão existe, mas deve ser expandida para todas as ações administrativas.
