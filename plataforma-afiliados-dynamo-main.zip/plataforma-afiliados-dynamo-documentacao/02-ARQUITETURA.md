# 2. Arquitetura

## Estilo arquitetural

A aplicação utiliza uma arquitetura monolítica full-stack em Next.js:

- o frontend é renderizado pelo App Router;
- páginas e layouts vivem em `app/`;
- Server Actions ficam em `actions/`;
- integrações e acesso a dados são agrupados em `services/` e `lib/`;
- o Prisma é responsável pelo acesso ao PostgreSQL;
- o Auth.js controla autenticação e sessão;
- serviços externos são acessados diretamente pelo backend Next.js.

```mermaid
flowchart LR
    Browser[Navegador] --> Next[Next.js App Router]
    Next --> Auth[Auth.js]
    Next --> Actions[Server Actions]
    Next --> Routes[API Routes]
    Actions --> Prisma[Prisma ORM]
    Routes --> Prisma
    Prisma --> DB[(PostgreSQL / Supabase)]
    Actions --> Shopify[Shopify Admin GraphQL]
    Actions --> Resend[Resend]
    Routes --> UploadThing[UploadThing]
```

## Camadas

### Apresentação

- `app/`
- `components/`
- `hooks/`

### Aplicação

- `actions/`
- validações em `lib/validations/`

### Domínio e serviços

- `services/conversion.ts`
- `services/user.service.ts`
- `services/shopify.service.ts`
- `services/email.service.ts`

### Infraestrutura

- `lib/prisma.ts`
- `lib/supabase.ts`
- `lib/resend.ts`
- `lib/uploadthing.ts`
- `lib/auth.ts`
- `middleware.ts`

## Decisões importantes

- sessão JWT no Auth.js;
- persistência de entidades de negócio em PostgreSQL;
- transações serializáveis na conversão de saldo;
- uso de `Decimal` no Prisma para valores monetários;
- separação parcial entre UI, validação, serviços e infraestrutura;
- integrações externas executadas somente no servidor com `server-only`.

## Pontos arquiteturais pendentes

- fila ou worker para notificações;
- processamento idempotente de webhooks;
- camada explícita de autorização por recurso;
- jobs agendados para expiração de cupons;
- abstração de provedor de WhatsApp;
- mecanismo confiável para consumir comissões em conversões aprovadas.
