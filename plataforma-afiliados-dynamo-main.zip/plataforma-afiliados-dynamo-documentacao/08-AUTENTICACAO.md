# 8. Autenticação e Autorização

## Tecnologia

- Auth.js / NextAuth v5 beta;
- provider de credenciais;
- bcrypt para senha;
- sessão JWT;
- Prisma para acesso ao usuário;
- Zod para validar entrada.

## Fluxo de cadastro

```mermaid
sequenceDiagram
    participant U as Usuário
    participant F as Formulário
    participant A as Server Action
    participant P as Prisma
    U->>F: Preenche cadastro
    F->>A: Envia dados
    A->>A: Valida com Zod
    A->>A: Cria hash bcrypt
    A->>P: Cria User + Affiliate
    P-->>A: Confirma transação
    A-->>F: Resultado
```

O perfil de afiliado é criado com status inicial `PENDING`.

## Fluxo de login

O Auth.js consulta o usuário, compara o hash de senha e inclui `id` e `role` na sessão.

## Middleware

O middleware:

- libera rotas públicas;
- redireciona usuários autenticados para o dashboard quando acessam páginas de login;
- redireciona não autenticados para `/login`;
- libera todas as rotas iniciadas com `/api`.

### Risco

A liberação genérica de `/api` significa que cada API futura deverá implementar sua própria autenticação e autorização. Caso contrário, endpoints administrativos podem ficar públicos.

## Papéis

- `ADMIN`
- `AFFILIATE`

Não foi localizada uma camada central de autorização baseada em papel para páginas e APIs administrativas.

## Recuperação de senha

A interface existe, mas ainda faltam:

- token;
- armazenamento;
- e-mail;
- rota de redefinição;
- expiração;
- consumo único.
