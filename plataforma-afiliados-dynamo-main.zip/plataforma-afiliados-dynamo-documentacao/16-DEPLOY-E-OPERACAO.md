# 16. Deploy e Operação

## Opção natural

Por ser Next.js, o projeto pode ser implantado na Vercel ou em ambiente Node.js compatível.

## Dependências externas

- PostgreSQL/Supabase;
- Shopify;
- Resend;
- UploadThing.

## Checklist de produção

- configurar variáveis;
- gerar Prisma Client;
- aplicar migrations;
- validar domínio Auth.js;
- configurar domínio de e-mail;
- configurar token e escopos Shopify;
- registrar webhooks;
- configurar logs;
- habilitar monitoramento;
- criar política de backup;
- configurar rate limiting;
- testar rollback.

## Observabilidade recomendada

- logs estruturados com request ID;
- captura de exceções;
- métricas de webhooks;
- métricas de envio;
- alertas para falhas Shopify;
- auditoria administrativa;
- monitoramento da conexão PostgreSQL;
- SLI de login, webhook e conversão.

## CI/CD

O pacote não contém GitHub Actions. Um pipeline mínimo deve executar instalação bloqueada, geração Prisma, lint e build.
