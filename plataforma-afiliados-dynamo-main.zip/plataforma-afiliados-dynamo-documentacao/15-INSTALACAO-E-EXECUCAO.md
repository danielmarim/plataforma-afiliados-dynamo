# 15. Instalação e Execução

## Pré-requisitos

- Node.js compatível com Next.js 15;
- pnpm;
- PostgreSQL ou projeto Supabase;
- credenciais dos serviços usados.

## Instalação

```bash
pnpm install
```

## Configuração

Crie `.env` a partir do modelo documentado.

## Prisma

```bash
pnpm prisma generate
pnpm prisma db push
```

Para ambientes controlados, prefira migrations:

```bash
pnpm prisma migrate dev --name initial
```

## Desenvolvimento

```bash
pnpm dev
```

## Qualidade

```bash
pnpm lint
pnpm build
```

## Observação

O projeto não possui script de testes no `package.json`.
