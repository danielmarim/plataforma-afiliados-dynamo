# 6. Backend e Server Actions

## Server Actions

- `actions/auth.ts`

`actions/auth.ts` concentra os fluxos de autenticação do projeto. A validação fica em `lib/validations/auth.ts`.

## Serviços

- `services/conversion.ts`
- `services/email.service.ts`
- `services/shopify.service.ts`
- `services/user.service.ts`

### `user.service.ts`

Responsável por consultas de usuário por ID ou e-mail, incluindo o perfil do afiliado.

### `shopify.service.ts`

Implementa o cliente genérico `shopifyAdminFetch<T>`, enviando consultas GraphQL autenticadas.

Operações ainda comentadas e não implementadas:

- `createDiscountCode`;
- `getOrder`;
- `registerWebhooks`.

### `email.service.ts`

Fornece um método genérico de envio por Resend.

### `conversion.ts`

Implementa a parte mais detalhada das regras de negócio:

- cálculo de saldo;
- cálculo de saldo reservado;
- criação de solicitação;
- aprovação;
- rejeição;
- geração de código;
- validade;
- auditoria;
- criação de registros de notificação.

## Tratamento de concorrência

As operações de conversão usam transações Prisma com isolamento `Serializable`. Isso reduz corridas, mas o comentário sobre `SELECT FOR UPDATE` não corresponde ao código, pois `findMany` não emite explicitamente um lock de linha.

## APIs internas ausentes

Não foram encontradas rotas HTTP específicas para:

- conversões;
- aprovação administrativa;
- afiliados;
- cupons;
- vendas;
- notificações;
- biblioteca.
