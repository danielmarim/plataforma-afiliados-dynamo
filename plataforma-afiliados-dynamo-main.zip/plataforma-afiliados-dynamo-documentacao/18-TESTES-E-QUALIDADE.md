# 18. Testes e Qualidade

## Situação

Não existem testes automatizados no pacote.

## Prioridade de testes

1. Cadastro.
2. Login.
3. Autorização por papel.
4. Cálculo de saldo.
5. Solicitação concorrente.
6. Aprovação e rejeição.
7. Geração de código único.
8. Validade de 15 dias.
9. Webhook idempotente.
10. Cálculo e reversão de comissão.
11. Upload.
12. Recuperação de senha.

## Ferramentas sugeridas

- Vitest para unidade;
- Testing Library para componentes;
- Playwright para E2E;
- banco isolado para integração.

## Qualidade estática

O projeto tem ESLint e TypeScript. Recomenda-se adicionar:

- `typecheck`;
- testes no CI;
- cobertura;
- auditoria de dependências;
- formatter;
- hooks de pre-commit.
