# 5. Frontend

## Páginas encontradas

| Rota | Arquivo | Tipo |
|---|---|---|
| /forgot-password | app/(auth)/forgot-password/page.tsx | Página |
| /login | app/(auth)/login/page.tsx | Página |
| /register | app/(auth)/register/page.tsx | Página |
| /dashboard | app/(dashboard)/dashboard/page.tsx | Página |
| /api/auth/[...nextauth] | app/api/auth/[...nextauth]/route.ts | API Route |
| /api/uploadthing | app/api/uploadthing/route.ts | API Route |
| / | app/page.tsx | Página |

## Componentes de autenticação

- `components/auth/forgot-password-form.tsx`
- `components/auth/login-form.tsx`
- `components/auth/register-form.tsx`

## Componentes do dashboard

- `components/dashboard/sidebar-nav.tsx`
- `components/dashboard/user-nav.tsx`

## Componentes de interface

- `components/ui/avatar.tsx`
- `components/ui/badge.tsx`
- `components/ui/button.tsx`
- `components/ui/card.tsx`
- `components/ui/dropdown-menu.tsx`
- `components/ui/form.tsx`
- `components/ui/input.tsx`
- `components/ui/label.tsx`
- `components/ui/separator.tsx`
- `components/ui/sheet.tsx`
- `components/ui/skeleton.tsx`
- `components/ui/sonner.tsx`
- `components/ui/table.tsx`
- `components/ui/tabs.tsx`

## Providers

- `components/providers/session-provider.tsx`: disponibiliza a sessão Auth.js para componentes clientes.

## Hooks

- `hooks/use-current-user.ts`
- `hooks/use-uploadthing.ts`

## Situação do dashboard

Existe uma estrutura inicial de dashboard protegida. Não foram localizados os módulos finais de:

- vendas;
- comissões;
- solicitações;
- cupons;
- biblioteca;
- relatórios;
- configurações de afiliado;
- gestão administrativa.

## Design system

O projeto usa convenções do Shadcn/UI e Tailwind. Os componentes básicos são locais, permitindo personalização sem depender de um pacote fechado.
